#ifndef MAIN_H
#define MAIN_H

#include "qcustomplot.h"
#include "widget.h"
#include "math.h"

#endif // MAIN_H
